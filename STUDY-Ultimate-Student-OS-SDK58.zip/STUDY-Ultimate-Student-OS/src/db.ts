import * as SQLite from 'expo-sqlite';

export type Subject = { id:number; name:string; color:string; total:number; done:number };
export type Chapter = { id:number; subject_id:number; name:string; priority:string; status:string; estimate:number; actual:number; done:number };
export type Task = { id:number; title:string; subject_id:number|null; chapter_id:number|null; date:string; start_time:string; duration:number; done:number };

export async function initDb(db: SQLite.SQLiteDatabase) {
  await db.execAsync(`
    PRAGMA journal_mode = WAL;
    PRAGMA foreign_keys = ON;
    CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS subjects (
      id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, color TEXT NOT NULL DEFAULT '#5B8CFF',
      sort_order INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS chapters (
      id INTEGER PRIMARY KEY AUTOINCREMENT, subject_id INTEGER NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
      name TEXT NOT NULL, description TEXT DEFAULT '', priority TEXT NOT NULL DEFAULT 'Medium',
      status TEXT NOT NULL DEFAULT 'Not Started', estimate INTEGER NOT NULL DEFAULT 60,
      actual INTEGER NOT NULL DEFAULT 0, difficulty INTEGER NOT NULL DEFAULT 3,
      notes TEXT DEFAULT '', done INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS tasks (
      id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, subject_id INTEGER REFERENCES subjects(id) ON DELETE SET NULL,
      chapter_id INTEGER REFERENCES chapters(id) ON DELETE SET NULL, date TEXT NOT NULL,
      start_time TEXT NOT NULL DEFAULT '18:00', duration INTEGER NOT NULL DEFAULT 60,
      done INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS study_sessions (
      id INTEGER PRIMARY KEY AUTOINCREMENT, subject_id INTEGER REFERENCES subjects(id) ON DELETE SET NULL,
      chapter_id INTEGER REFERENCES chapters(id) ON DELETE SET NULL, started_at TEXT NOT NULL,
      duration INTEGER NOT NULL, mode TEXT NOT NULL DEFAULT 'Focus'
    );
    CREATE TABLE IF NOT EXISTS revisions (
      id INTEGER PRIMARY KEY AUTOINCREMENT, chapter_id INTEGER NOT NULL REFERENCES chapters(id) ON DELETE CASCADE,
      due_date TEXT NOT NULL, completed_at TEXT, interval_days INTEGER NOT NULL DEFAULT 1
    );
    CREATE TABLE IF NOT EXISTS notes (
      id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, body TEXT NOT NULL DEFAULT '',
      subject_id INTEGER REFERENCES subjects(id) ON DELETE SET NULL, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS habits (
      id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, private INTEGER NOT NULL DEFAULT 0,
      active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS habit_checks (
      id INTEGER PRIMARY KEY AUTOINCREMENT, habit_id INTEGER NOT NULL REFERENCES habits(id) ON DELETE CASCADE,
      day TEXT NOT NULL, value INTEGER NOT NULL DEFAULT 1, UNIQUE(habit_id, day)
    );
    CREATE TABLE IF NOT EXISTS tests (
      id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, subject_id INTEGER REFERENCES subjects(id) ON DELETE SET NULL,
      score REAL NOT NULL DEFAULT 0, total REAL NOT NULL DEFAULT 0, taken_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS achievements (
      id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT UNIQUE NOT NULL, unlocked_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
  `);
  const seeded = await db.getFirstAsync<{value:string}>("SELECT value FROM settings WHERE key='seeded'");
  if (!seeded) {
    const defaults = [['Bengali','#F59E0B'],['English','#22C55E'],['Physics','#5B8CFF'],['Chemistry','#A78BFA'],['Biology','#14B8A6']];
    for (let i=0;i<defaults.length;i++) await db.runAsync("INSERT INTO subjects(name,color,sort_order) VALUES(?,?,?)",defaults[i][0],defaults[i][1],i);
    await db.runAsync("INSERT INTO settings(key,value) VALUES('exam_date',?)", new Date(Date.now()+90*86400000).toISOString().slice(0,10));
    await db.runAsync("INSERT INTO settings(key,value) VALUES('daily_goal','4')");
    await db.runAsync("INSERT INTO settings(key,value) VALUES('seeded','1')");
  }
}

export const today = () => new Date().toISOString().slice(0,10);
export async function getSubjects(db:SQLite.SQLiteDatabase):Promise<Subject[]> {
  return db.getAllAsync(`SELECT s.id,s.name,s.color,COUNT(c.id) total,
    SUM(CASE WHEN c.done=1 THEN 1 ELSE 0 END) done FROM subjects s
    LEFT JOIN chapters c ON c.subject_id=s.id GROUP BY s.id ORDER BY s.sort_order,s.id`);
}
