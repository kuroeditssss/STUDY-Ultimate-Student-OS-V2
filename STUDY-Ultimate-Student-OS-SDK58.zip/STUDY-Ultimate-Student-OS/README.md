# STUDY – Ultimate Student OS (Android-first starter)

A local-first Expo / React Native app for a WBCHSE Class 12 student's study workflow.

## Runtime baseline
- Expo SDK 58
- React Native 0.88 / React 19.3
- Node.js 22.13 or newer (22.x or 24.3+ recommended by Expo SDK 58)
- Expo Go must support SDK 58; alternatively use an EAS development build.

## Implemented in this starter
- Persistent SQLite database on the device (WAL mode).
- Default subjects: Bengali, English, Physics, Chemistry, Biology.
- Subject and chapter creation; chapter completion updates progress.
- Completing a chapter schedules 1-, 3-, and 7-day revision reminders in the local database.
- Daily task creation, completion and deletion.
- Focus timer presets; this starter records focus time when stopped.
- Exam date and daily goal settings.
- Home dashboard with real chapter/task/focus data.
- Local data survives app restarts.

## Not yet implemented
Authentication/cloud sync, notifications, full calendar, timer background persistence, AI, test engine, private PIN-protected habits, attachments, backup/restore, and advanced analytics are not included yet. The More screen labels these honestly rather than pretending they work. This is a functional foundation, not a production-complete release.

## Install and run
```bash
npm install
npx expo install --fix
npx expo-doctor
npx expo start
```

Open Expo Go on Android and scan the QR code (or enter the development URL). If Expo Go reports an SDK mismatch, confirm that the installed Expo Go build supports SDK 58.

## Build an Android APK (cloud build)
```bash
npm install -g eas-cli
eas login
eas build:configure
eas build --platform android --profile preview
```
The `preview` profile is configured to produce an APK. EAS will provide the install link when the cloud build completes.

## Local native build
```bash
npx expo prebuild --platform android
npx expo run:android
```

## Data and privacy
All academic data in this starter is stored in `study.db` on the device. No account, remote database, or AI provider is configured. Uninstalling the app may remove its local database; export/restore is a planned feature and is not available yet.
