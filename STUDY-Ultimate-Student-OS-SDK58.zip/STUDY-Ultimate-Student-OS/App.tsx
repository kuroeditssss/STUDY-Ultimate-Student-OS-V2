import React, {useEffect,useMemo,useState} from 'react';
import { Alert, FlatList, KeyboardAvoidingView, Modal, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { SQLiteProvider, useSQLiteContext } from 'expo-sqlite';
import { NavigationContainer, DarkTheme } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import { initDb, getSubjects, today, Subject, Chapter, Task } from './src/db';

const C={bg:'#070A12',panel:'#101625',panel2:'#151E30',line:'#253149',text:'#F4F7FF',muted:'#8C9AB2',blue:'#5B8CFF',purple:'#A78BFA',green:'#35D39A',orange:'#F5B84B',red:'#FF6B78'};
const Tab=createBottomTabNavigator();
const dateLabel=new Date().toLocaleDateString('en-IN',{weekday:'long',day:'numeric',month:'short'});
const daysUntil=(d:string)=>Math.max(0,Math.ceil((new Date(d+'T00:00:00').getTime()-new Date(today()+'T00:00:00').getTime())/86400000));

function Screen({children}:any){return <View style={s.screen}>{children}</View>}
function Header({title,sub}:any){return <View style={{marginBottom:20}}><Text style={s.eyebrow}>STUDY / STUDENT OS</Text><Text style={s.h1}>{title}</Text>{sub?<Text style={s.muted}>{sub}</Text>:null}</View>}
function Card({children,style}:any){return <View style={[s.card,style]}>{children}</View>}
function Btn({title,onPress,secondary=false}:any){return <Pressable onPress={onPress} style={[s.btn,secondary&&s.btnSecondary]}><Text style={[s.btnText,secondary&&{color:C.text}]}>{title}</Text></Pressable>}
function Field({label,value,onChangeText,placeholder,keyboardType='default'}:any){return <View style={{marginBottom:12}}><Text style={s.label}>{label}</Text><TextInput value={value} onChangeText={onChangeText} placeholder={placeholder} placeholderTextColor={C.muted} keyboardType={keyboardType} style={s.input}/></View>}
function Progress({value}:any){return <View style={s.track}><View style={[s.fill,{width:`${Math.max(0,Math.min(100,value))}%`}]}/></View>}

function Home(){
 const db=useSQLiteContext(); const [subjects,setSubjects]=useState<Subject[]>([]); const [tasks,setTasks]=useState<Task[]>([]);
 const [exam,setExam]=useState(''); const [goal,setGoal]=useState('4'); const [minutes,setMinutes]=useState(0);
 const load=async()=>{setSubjects(await getSubjects(db));setTasks(await db.getAllAsync("SELECT * FROM tasks WHERE date=? ORDER BY start_time",today()));const e=await db.getFirstAsync<any>("SELECT value FROM settings WHERE key='exam_date'");setExam(e?.value||'');const g=await db.getFirstAsync<any>("SELECT value FROM settings WHERE key='daily_goal'");setGoal(g?.value||'4');const m=await db.getFirstAsync<any>("SELECT COALESCE(SUM(duration),0) n FROM study_sessions WHERE date(started_at)=?",today());setMinutes(m?.n||0)};
 useEffect(()=>{load();const t=setInterval(load,5000);return()=>clearInterval(t)},[]);
 const total=subjects.reduce((a,b)=>a+b.total,0),done=subjects.reduce((a,b)=>a+b.done,0),pct=total?Math.round(done/total*100):0;
 const complete=tasks.filter(t=>t.done).length;
 return <Screen><ScrollView showsVerticalScrollIndicator={false}>
  <Header title="Good evening." sub={dateLabel}/>
  <Card style={{backgroundColor:'#111D35',borderColor:'#2C4778'}}><Text style={s.label}>EXAM COUNTDOWN</Text><View style={{flexDirection:'row',alignItems:'baseline',gap:8}}><Text style={[s.big,{color:C.blue}]}>{exam?daysUntil(exam):'—'}</Text><Text style={s.muted}>days remaining</Text></View><Text style={s.small}>Your next milestone: finish the syllabus, one focused session at a time.</Text></Card>
  <View style={s.row}><Card style={{flex:1}}><Text style={s.label}>SYLLABUS</Text><Text style={s.metric}>{pct}%</Text><Progress value={pct}/><Text style={s.small}>{done} of {total} chapters</Text></Card><Card style={{flex:1}}><Text style={s.label}>FOCUS TODAY</Text><Text style={s.metric}>{(minutes/60).toFixed(1)}h</Text><Text style={s.small}>Goal: {goal} hours</Text><Progress value={Math.min(100,minutes/(Number(goal)*60)*100)}/></Card></View>
  <Text style={s.section}>Subject progress</Text>
  {subjects.map(x=><Card key={x.id} style={{marginBottom:10}}><View style={s.rowBetween}><Text style={s.cardTitle}>{x.name}</Text><Text style={s.small}>{x.done}/{x.total} chapters</Text></View><Progress value={x.total?x.done/x.total*100:0}/></Card>)}
  <Text style={s.section}>Today's targets <Text style={s.muted}>{complete}/{tasks.length}</Text></Text>
  {tasks.length?tasks.map(t=><Pressable key={t.id} onPress={async()=>{await db.runAsync("UPDATE tasks SET done=? WHERE id=?",t.done?0:1,t.id);load()}} style={s.task}><Ionicons name={t.done?'checkmark-circle':'ellipse-outline'} size={22} color={t.done?C.green:C.muted}/><View style={{flex:1}}><Text style={[s.cardTitle,t.done&&{textDecorationLine:'line-through',color:C.muted}]}>{t.title}</Text><Text style={s.small}>{t.start_time} · {t.duration} min</Text></View></Pressable>):<Card><Text style={s.muted}>No tasks planned yet. Add today's first target in Planner.</Text></Card>}
 </ScrollView></Screen>
}

function Subjects(){
 const db=useSQLiteContext();const [subjects,setSubjects]=useState<Subject[]>([]);const [selected,setSelected]=useState<number|null>(null);const [chapters,setChapters]=useState<Chapter[]>([]);const [modal,setModal]=useState(false);const [name,setName]=useState('');const [subjectName,setSubjectName]=useState('');
 const load=async()=>{const a=await getSubjects(db);setSubjects(a);if(selected!==null)setChapters(await db.getAllAsync("SELECT * FROM chapters WHERE subject_id=? ORDER BY id DESC",selected))};
 useEffect(()=>{load()},[selected]);
 const addSubject=async()=>{if(!subjectName.trim())return;await db.runAsync("INSERT INTO subjects(name) VALUES(?)",subjectName.trim());setSubjectName('');load()};
 const addChapter=async()=>{if(!name.trim()||selected===null)return;await db.runAsync("INSERT INTO chapters(subject_id,name) VALUES(?,?)",selected,name.trim());setName('');setModal(false);load()};
 const toggle=async(c:Chapter)=>{const done=c.done?0:1;await db.runAsync("UPDATE chapters SET done=?,status=? WHERE id=?",done,done?'Completed':'Not Started',c.id);if(done){for(const n of [1,3,7])await db.runAsync("INSERT INTO revisions(chapter_id,due_date,interval_days) VALUES(?,?,?)",c.id,new Date(Date.now()+n*86400000).toISOString().slice(0,10),n)}load()};
 return <Screen><Header title="Subjects" sub="Build your syllabus, chapter by chapter."/>
 {selected===null?<><View style={s.rowBetween}><Text style={s.section}>Your subjects</Text><Text style={s.small}>{subjects.length} total</Text></View>{subjects.map(x=><Pressable key={x.id} onPress={()=>setSelected(x.id)}><Card style={{marginBottom:10}}><View style={s.rowBetween}><Text style={s.cardTitle}>{x.name}</Text><Ionicons name="chevron-forward" color={C.muted} size={20}/></View><Progress value={x.total?x.done/x.total*100:0}/><Text style={s.small}>{x.done} completed · {x.total-x.done} pending</Text></Card></Pressable>)}<Field label="ADD SUBJECT" value={subjectName} onChangeText={setSubjectName} placeholder="e.g. Mathematics"/><Btn title="＋ Add subject" onPress={addSubject}/></>:<><Pressable onPress={()=>setSelected(null)}><Text style={s.link}>‹ All subjects</Text></Pressable><Text style={s.section}>{subjects.find(x=>x.id===selected)?.name||'Chapters'}</Text>{chapters.map(c=><Card key={c.id} style={{marginBottom:9}}><View style={s.rowBetween}><Text style={[s.cardTitle,{flex:1}]}>{c.name}</Text><Pressable onPress={()=>toggle(c)}><Ionicons name={c.done?'checkmark-circle':'ellipse-outline'} size={24} color={c.done?C.green:C.muted}/></Pressable></View><Text style={s.small}>{c.priority} priority · {c.estimate} min · {c.status}</Text></Card>)}{!chapters.length&&<Card><Text style={s.muted}>No chapters yet. Add the chapters from your actual WBCHSE syllabus.</Text></Card>}<Btn title="＋ Add chapter" onPress={()=>setModal(true)}/></>}
 <Modal visible={modal} transparent animationType="slide" onRequestClose={()=>setModal(false)}><KeyboardAvoidingView behavior={Platform.OS==='ios'?'padding':undefined} style={s.modalWrap}><View style={s.modal}><Text style={s.cardTitle}>New chapter</Text><Field label="CHAPTER NAME" value={name} onChangeText={setName} placeholder="Enter chapter name"/><Btn title="Save chapter" onPress={addChapter}/><Btn title="Cancel" secondary onPress={()=>setModal(false)}/></View></KeyboardAvoidingView></Modal>
 </Screen>
}

function Planner(){
 const db=useSQLiteContext();const [tasks,setTasks]=useState<Task[]>([]);const [title,setTitle]=useState('');const [duration,setDuration]=useState('60');const [time,setTime]=useState('18:00');
 const load=async()=>setTasks(await db.getAllAsync("SELECT * FROM tasks WHERE date=? ORDER BY start_time",today()));
 useEffect(()=>{load()},[]);
 const add=async()=>{if(!title.trim())return;await db.runAsync("INSERT INTO tasks(title,date,start_time,duration) VALUES(?,?,?,?)",title.trim(),today(),time,Math.max(5,Number(duration)||60));setTitle('');load()};
 const remove=(id:number)=>Alert.alert('Delete task?','This task will be permanently removed.',[{text:'Cancel'},{text:'Delete',style:'destructive',onPress:async()=>{await db.runAsync("DELETE FROM tasks WHERE id=?",id);load()}}]);
 return <Screen><Header title="Planner" sub="A realistic plan beats a perfect plan."/><Text style={s.section}>Today · {today()}</Text><Field label="TASK" value={title} onChangeText={setTitle} placeholder="e.g. Revise Newton's laws"/><View style={s.row}><View style={{flex:1}}><Field label="START TIME" value={time} onChangeText={setTime} placeholder="18:00"/></View><View style={{flex:1}}><Field label="DURATION (MIN)" value={duration} onChangeText={setDuration} keyboardType="numeric" placeholder="60"/></View></View><Btn title="＋ Add to today's plan" onPress={add}/><Text style={s.section}>Your schedule</Text>{tasks.map(t=><Card key={t.id} style={{marginTop:9}}><View style={s.rowBetween}><View style={{flex:1}}><Text style={s.cardTitle}>{t.title}</Text><Text style={s.small}>{t.start_time} · {t.duration} min</Text></View><Pressable onPress={async()=>{await db.runAsync("UPDATE tasks SET done=? WHERE id=?",t.done?0:1,t.id);load()}}><Ionicons name={t.done?'checkmark-circle':'ellipse-outline'} color={t.done?C.green:C.muted} size={24}/></Pressable><Pressable onPress={()=>remove(t.id)} style={{marginLeft:14}}><Ionicons name="trash-outline" color={C.red} size={20}/></Pressable></View></Card>)}{!tasks.length&&<Text style={s.muted}>Your day is open. Add a task above to get started.</Text>}</Screen>
}

function Focus(){
 const db=useSQLiteContext();const [mode,setMode]=useState('Pomodoro');const [seconds,setSeconds]=useState(25*60);const [running,setRunning]=useState(false);const [elapsed,setElapsed]=useState(0);const [started,setStarted]=useState<string|null>(null);
 const presets:any={Pomodoro:25*60,'Long focus':50*60,Custom:40*60};
 useEffect(()=>{if(!running)return;const id=setInterval(()=>{setElapsed(v=>v+1);setSeconds(v=>{if(v<=1){setRunning(false);Alert.alert('Session complete','Great work. Take a short break.');return 0}return v-1})},1000);return()=>clearInterval(id)},[running]);
 const choose=(m:string)=>{setRunning(false);setMode(m);setSeconds(presets[m]);setElapsed(0);setStarted(null)};
 const finish=async()=>{setRunning(false);const mins=Math.max(1,Math.round(elapsed/60));if(mins>0)await db.runAsync("INSERT INTO study_sessions(started_at,duration,mode) VALUES(?,?,?)",started||new Date().toISOString(),mins,mode);setElapsed(0);setStarted(null);Alert.alert('Session saved',`${mins} minutes added to your focus history.`)};
 const clock=`${String(Math.floor(seconds/60)).padStart(2,'0')}:${String(seconds%60).padStart(2,'0')}`;
 return <Screen><Header title="Focus Room" sub="One task. One session. Full attention."/><View style={s.modeRow}>{Object.keys(presets).map(m=><Pressable key={m} onPress={()=>choose(m)} style={[s.modePill,mode===m&&s.modeActive]}><Text style={{color:mode===m?C.text:C.muted,fontWeight:'700'}}>{m}</Text></Pressable>)}</View><Card style={{alignItems:'center',paddingVertical:34,marginTop:28}}><Text style={s.label}>TIME REMAINING</Text><Text style={s.timer}>{clock}</Text><Text style={s.muted}>{running?'Stay in the zone.':seconds===0?'Session complete':'Ready when you are.'}</Text><View style={{height:20}}/><View style={s.row}><Btn title={running?'Pause':'Start'} onPress={()=>{if(!started)setStarted(new Date().toISOString());setRunning(!running)}}/><View style={{width:10}}/><Btn title="Stop & save" secondary onPress={finish}/></View></Card><Text style={s.section}>Focus principles</Text><Card><Text style={s.body}>• Keep only one chapter in front of you.</Text><Text style={s.body}>• Put your phone on silent during the session.</Text><Text style={s.body}>• Take breaks. Consistency matters more than extremes.</Text></Card></Screen>
}

function More(){
 const db=useSQLiteContext();const [exam,setExam]=useState('');const [goal,setGoal]=useState('4');const [sessions,setSessions]=useState(0);const [revisions,setRevisions]=useState<any[]>([]);
 const load=async()=>{const e=await db.getFirstAsync<any>("SELECT value FROM settings WHERE key='exam_date'");setExam(e?.value||'');const g=await db.getFirstAsync<any>("SELECT value FROM settings WHERE key='daily_goal'");setGoal(g?.value||'4');const ss=await db.getFirstAsync<any>("SELECT COUNT(*) n FROM study_sessions");setSessions(ss?.n||0);setRevisions(await db.getAllAsync("SELECT r.id,r.due_date,c.name chapter,s.name subject FROM revisions r JOIN chapters c ON c.id=r.chapter_id JOIN subjects s ON s.id=c.subject_id WHERE r.completed_at IS NULL ORDER BY r.due_date LIMIT 8"))};
 useEffect(()=>{load()},[]);
 return <Screen><Header title="More" sub="Your study system, your rules."/><Text style={s.section}>Mission settings</Text><Field label="EXAM DATE (YYYY-MM-DD)" value={exam} onChangeText={setExam} placeholder="2027-02-23"/><Field label="DAILY STUDY GOAL (HOURS)" value={goal} onChangeText={setGoal} keyboardType="numeric" placeholder="4"/><Btn title="Save settings" onPress={async()=>{await db.runAsync("INSERT OR REPLACE INTO settings(key,value) VALUES('exam_date',?)",exam);await db.runAsync("INSERT OR REPLACE INTO settings(key,value) VALUES('daily_goal',?)",goal);Alert.alert('Saved','Your mission settings have been updated.')}}/><Text style={s.section}>Revision queue</Text>{revisions.map(r=><Card key={r.id} style={{marginBottom:8}}><View style={s.rowBetween}><View style={{flex:1}}><Text style={s.cardTitle}>{r.chapter}</Text><Text style={s.small}>{r.subject} · Due {r.due_date}</Text></View><Pressable onPress={async()=>{await db.runAsync("UPDATE revisions SET completed_at=CURRENT_TIMESTAMP WHERE id=?",r.id);load()}}><Text style={s.link}>Done</Text></Pressable></View></Card>)}{!revisions.length&&<Card><Text style={s.muted}>Complete a chapter to automatically create 1, 3 and 7-day revisions.</Text></Card>}<Text style={s.section}>Your activity</Text><Card><Text style={s.metric}>{sessions}</Text><Text style={s.muted}>Focus sessions recorded on this device</Text></Card><Text style={s.section}>Coming in the next build</Text><Card><Text style={s.body}>AI assistant · Practice tests · Notes & formula bank · Private habit lock · Backup/export · Advanced analytics</Text><Text style={s.small}>These features are not activated in this starter build. No fake AI or cloud sync is shown.</Text></Card></Screen>
}

function Tabs(){
 return <Tab.Navigator screenOptions={({route})=>({headerShown:false,tabBarStyle:{backgroundColor:C.panel,borderTopColor:C.line,height:66,paddingBottom:8,paddingTop:8},tabBarActiveTintColor:C.blue,tabBarInactiveTintColor:C.muted,tabBarLabelStyle:{fontSize:11,fontWeight:'700'},tabBarIcon:({color,size})=>{const icons:any={Home:'grid',Subjects:'book',Planner:'calendar',Focus:'timer',More:'apps'};return <Ionicons name={icons[route.name]||'ellipse'} size={size} color={color}/>}})}>
 <Tab.Screen name="Home" component={Home}/><Tab.Screen name="Subjects" component={Subjects}/><Tab.Screen name="Planner" component={Planner}/><Tab.Screen name="Focus" component={Focus}/><Tab.Screen name="More" component={More}/>
 </Tab.Navigator>
}
function AppRoot(){return <SQLiteProvider databaseName="study.db" onInit={initDb}><NavigationContainer theme={{...DarkTheme,colors:{...DarkTheme.colors,background:C.bg,card:C.panel,text:C.text,border:C.line,primary:C.blue}}}><StatusBar style="light" /><Tabs/></NavigationContainer></SQLiteProvider>}
export default function App(){return <AppRoot/>}

const s=StyleSheet.create({
 screen:{flex:1,backgroundColor:C.bg,paddingHorizontal:18,paddingTop:Platform.OS==='android'?16:12},
 eyebrow:{color:C.blue,fontSize:10,fontWeight:'900',letterSpacing:2,marginBottom:7},
 h1:{fontSize:30,fontWeight:'800',color:C.text,letterSpacing:-.7},muted:{color:C.muted,fontSize:13,lineHeight:20},small:{color:C.muted,fontSize:11,marginTop:6},label:{color:C.muted,fontSize:10,fontWeight:'800',letterSpacing:1.2,marginBottom:8},
 card:{backgroundColor:C.panel,borderRadius:17,borderWidth:1,borderColor:C.line,padding:16,marginBottom:12},
 big:{fontSize:48,fontWeight:'900'},metric:{fontSize:29,fontWeight:'900',color:C.text,marginVertical:5},cardTitle:{fontSize:15,fontWeight:'700',color:C.text},section:{fontSize:17,fontWeight:'800',color:C.text,marginTop:17,marginBottom:12},
 row:{flexDirection:'row',alignItems:'center'},rowBetween:{flexDirection:'row',alignItems:'center',justifyContent:'space-between'},
 track:{height:6,backgroundColor:C.line,borderRadius:10,overflow:'hidden',marginVertical:10},fill:{height:6,backgroundColor:C.blue,borderRadius:10},
 btn:{backgroundColor:C.blue,borderRadius:12,paddingVertical:13,paddingHorizontal:17,alignItems:'center',justifyContent:'center'},btnSecondary:{backgroundColor:C.panel2,borderWidth:1,borderColor:C.line},btnText:{color:'#fff',fontWeight:'800',fontSize:13},
 input:{backgroundColor:C.panel,borderColor:C.line,borderWidth:1,borderRadius:11,padding:13,color:C.text,fontSize:14},task:{flexDirection:'row',alignItems:'center',gap:12,paddingVertical:13,borderBottomWidth:1,borderColor:C.line},
 link:{color:C.blue,fontWeight:'800',fontSize:13,marginVertical:12},body:{color:C.text,fontSize:13,lineHeight:24},
 modeRow:{flexDirection:'row',gap:8},modePill:{padding:11,borderRadius:12,borderWidth:1,borderColor:C.line,backgroundColor:C.panel},modeActive:{backgroundColor:'#1A2A4A',borderColor:C.blue},
 timer:{fontSize:64,fontWeight:'900',color:C.text,letterSpacing:-2,marginVertical:12},
 modalWrap:{flex:1,justifyContent:'flex-end',backgroundColor:'#0009'},modal:{backgroundColor:C.panel,padding:22,borderTopLeftRadius:22,borderTopRightRadius:22}
});
